import { OrganismIdentification } from "@/shared/types";
import { Leaf, MapPin, Utensils, Heart, Sparkles, Shield } from "lucide-react";

interface OrganismCardProps {
  identification: OrganismIdentification;
}

export default function OrganismCard({ identification }: OrganismCardProps) {
  const confidencePercentage = Math.round(identification.confidence_score * 100);
  
  const getConfidenceColor = (score: number) => {
    if (score >= 0.9) return "text-green-600 bg-green-100";
    if (score >= 0.7) return "text-yellow-600 bg-yellow-100";
    return "text-red-600 bg-red-100";
  };

  return (
    <div className="bg-white/90 backdrop-blur-sm rounded-2xl shadow-xl border border-green-100 overflow-hidden hover:shadow-2xl transition-all duration-300 hover:scale-[1.02]">
      {/* Header with organism name and confidence */}
      <div className="bg-gradient-to-r from-green-500 via-emerald-500 to-teal-500 p-6 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold mb-1">{identification.common_name}</h2>
            <p className="text-green-100 italic text-lg">{identification.organism_name}</p>
          </div>
          <div className={`px-3 py-1 rounded-full text-sm font-semibold ${getConfidenceColor(identification.confidence_score)}`}>
            {confidencePercentage}% confident
          </div>
        </div>
        {identification.is_educational_mode && (
          <div className="mt-3 flex items-center gap-2 bg-white/20 rounded-lg px-3 py-1 w-fit">
            <Sparkles className="w-4 h-4" />
            <span className="text-sm font-medium">Educational Mode</span>
          </div>
        )}
      </div>

      {/* Image if available */}
      {identification.image_key && (
        <div className="h-48 overflow-hidden bg-gradient-to-b from-green-50 to-green-100">
          <img
            src={`/api/images/${identification.image_key.split('/').pop()}`}
            alt={identification.common_name}
            className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
          />
        </div>
      )}

      {/* Content */}
      <div className="p-6 space-y-5">
        {/* Classification */}
        <div className="bg-gradient-to-r from-green-50 to-emerald-50 rounded-xl p-4">
          <h3 className="text-lg font-semibold text-green-800 mb-2 flex items-center gap-2">
            <Leaf className="w-5 h-5" />
            Classification
          </h3>
          <p className="text-green-700 leading-relaxed">{identification.scientific_classification}</p>
        </div>

        {/* Key information grid */}
        <div className="grid md:grid-cols-2 gap-4">
          <InfoItem
            icon={<MapPin className="w-5 h-5" />}
            title="Habitat"
            content={identification.habitat}
            bgColor="bg-blue-50"
            textColor="text-blue-800"
            contentColor="text-blue-700"
          />
          
          <InfoItem
            icon={<Utensils className="w-5 h-5" />}
            title="Diet"
            content={identification.diet}
            bgColor="bg-amber-50"
            textColor="text-amber-800"
            contentColor="text-amber-700"
          />
          
          <InfoItem
            icon={<Heart className="w-5 h-5" />}
            title="Benefits"
            content={identification.benefits}
            bgColor="bg-pink-50"
            textColor="text-pink-800"
            contentColor="text-pink-700"
          />
          
          <InfoItem
            icon={<Shield className="w-5 h-5" />}
            title="Conservation"
            content={identification.conservation_status}
            bgColor="bg-purple-50"
            textColor="text-purple-800"
            contentColor="text-purple-700"
          />
        </div>

        {/* Unique characteristics */}
        <div className="bg-gradient-to-r from-teal-50 to-cyan-50 rounded-xl p-4">
          <h3 className="text-lg font-semibold text-teal-800 mb-2 flex items-center gap-2">
            <Sparkles className="w-5 h-5" />
            Unique Characteristics
          </h3>
          <p className="text-teal-700 leading-relaxed">{identification.unique_characteristics}</p>
        </div>

        {/* Timestamp */}
        <div className="text-center text-sm text-green-600 bg-green-50 rounded-lg py-2">
          Identified on {new Date(identification.created_at).toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'long',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
          })}
        </div>
      </div>
    </div>
  );
}

interface InfoItemProps {
  icon: React.ReactNode;
  title: string;
  content: string;
  bgColor: string;
  textColor: string;
  contentColor: string;
}

function InfoItem({ icon, title, content, bgColor, textColor, contentColor }: InfoItemProps) {
  return (
    <div className={`${bgColor} rounded-xl p-4`}>
      <h4 className={`font-semibold ${textColor} mb-2 flex items-center gap-2`}>
        {icon}
        {title}
      </h4>
      <p className={`${contentColor} text-sm leading-relaxed`}>{content}</p>
    </div>
  );
}
