import { useState, useRef } from "react";
import { Camera, Type, Upload, Sparkles, Leaf, Search } from "lucide-react";

interface IdentificationFormProps {
  onSubmit: (data: { text?: string; image?: File; educationalMode: boolean }) => void;
  isLoading: boolean;
}

export default function IdentificationForm({ onSubmit, isLoading }: IdentificationFormProps) {
  const [inputType, setInputType] = useState<"text" | "image">("text");
  const [textInput, setTextInput] = useState("");
  const [selectedImage, setSelectedImage] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [educationalMode, setEducationalMode] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleImageSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setSelectedImage(file);
      const reader = new FileReader();
      reader.onload = (e) => {
        setImagePreview(e.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (inputType === "text" && textInput.trim()) {
      onSubmit({ text: textInput, educationalMode });
    } else if (inputType === "image" && selectedImage) {
      onSubmit({ image: selectedImage, educationalMode });
    }
  };

  const resetForm = () => {
    setTextInput("");
    setSelectedImage(null);
    setImagePreview(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  return (
    <div className="bg-white/95 backdrop-blur-sm rounded-3xl shadow-2xl p-8 border border-green-100">
      {/* Header */}
      <div className="text-center mb-8">
        <div className="inline-flex items-center gap-3 bg-gradient-to-r from-green-500 to-emerald-500 text-white px-6 py-3 rounded-full mb-4">
          <Leaf className="w-6 h-6" />
          <h2 className="text-xl font-bold">Identify Any Organism</h2>
        </div>
        <p className="text-green-700 text-lg">Type a description or upload a photo to discover nature's secrets</p>
      </div>

      {/* Input type selector */}
      <div className="flex bg-green-50 rounded-2xl p-1 mb-6">
        <button
          type="button"
          onClick={() => {
            setInputType("text");
            resetForm();
          }}
          className={`flex-1 flex items-center justify-center gap-2 py-3 px-4 rounded-xl font-semibold transition-all duration-300 ${
            inputType === "text"
              ? "bg-white shadow-md text-green-700"
              : "text-green-600 hover:text-green-700"
          }`}
        >
          <Type className="w-5 h-5" />
          Text Description
        </button>
        <button
          type="button"
          onClick={() => {
            setInputType("image");
            resetForm();
          }}
          className={`flex-1 flex items-center justify-center gap-2 py-3 px-4 rounded-xl font-semibold transition-all duration-300 ${
            inputType === "image"
              ? "bg-white shadow-md text-green-700"
              : "text-green-600 hover:text-green-700"
          }`}
        >
          <Camera className="w-5 h-5" />
          Photo Upload
        </button>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Text input */}
        {inputType === "text" && (
          <div>
            <label className="block text-green-800 font-semibold mb-3">
              Describe the organism you want to identify:
            </label>
            <textarea
              value={textInput}
              onChange={(e) => setTextInput(e.target.value)}
              placeholder="e.g., 'small red bird with black wings' or 'tall tree with white bark'"
              className="w-full p-4 border-2 border-green-200 rounded-xl focus:border-green-400 focus:ring-2 focus:ring-green-200 resize-none transition-all duration-300"
              rows={4}
              required={inputType === "text"}
            />
          </div>
        )}

        {/* Image input */}
        {inputType === "image" && (
          <div>
            <label className="block text-green-800 font-semibold mb-3">
              Upload a photo of the organism:
            </label>
            <div className="relative">
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleImageSelect}
                className="hidden"
                required={inputType === "image"}
              />
              
              {!imagePreview ? (
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="w-full border-2 border-dashed border-green-300 rounded-xl p-8 hover:border-green-400 hover:bg-green-50 transition-all duration-300 group"
                >
                  <div className="flex flex-col items-center gap-3">
                    <Upload className="w-12 h-12 text-green-500 group-hover:text-green-600" />
                    <div>
                      <p className="text-green-700 font-semibold">Click to upload image</p>
                      <p className="text-green-600 text-sm">JPG, PNG, or WEBP up to 10MB</p>
                    </div>
                  </div>
                </button>
              ) : (
                <div className="relative">
                  <img
                    src={imagePreview}
                    alt="Preview"
                    className="w-full max-h-64 object-cover rounded-xl"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      setImagePreview(null);
                      setSelectedImage(null);
                      if (fileInputRef.current) {
                        fileInputRef.current.value = "";
                      }
                    }}
                    className="absolute top-3 right-3 bg-red-500 text-white p-2 rounded-full hover:bg-red-600 transition-colors"
                  >
                    ✕
                  </button>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Educational mode toggle */}
        <div className="flex items-center gap-4 p-4 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl border border-blue-200">
          <div className="flex items-center">
            <input
              type="checkbox"
              id="educational-mode"
              checked={educationalMode}
              onChange={(e) => setEducationalMode(e.target.checked)}
              className="w-5 h-5 text-blue-600 rounded focus:ring-2 focus:ring-blue-500"
            />
            <label htmlFor="educational-mode" className="ml-3 cursor-pointer">
              <div className="flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-blue-600" />
                <span className="font-semibold text-blue-800">Educational Mode</span>
              </div>
            </label>
          </div>
          <p className="text-blue-700 text-sm flex-1">
            Get detailed information suitable for students and researchers
          </p>
        </div>

        {/* Submit button */}
        <button
          type="submit"
          disabled={isLoading || (inputType === "text" && !textInput.trim()) || (inputType === "image" && !selectedImage)}
          className="w-full bg-gradient-to-r from-green-500 via-emerald-500 to-teal-500 text-white font-bold py-4 px-6 rounded-xl hover:from-green-600 hover:via-emerald-600 hover:to-teal-600 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-300 transform hover:scale-[1.02] active:scale-[0.98] shadow-lg hover:shadow-xl flex items-center justify-center gap-3"
        >
          {isLoading ? (
            <>
              <div className="w-6 h-6 border-3 border-white border-t-transparent rounded-full animate-spin"></div>
              Identifying...
            </>
          ) : (
            <>
              <Search className="w-6 h-6" />
              Identify Organism
            </>
          )}
        </button>
      </form>
    </div>
  );
}
