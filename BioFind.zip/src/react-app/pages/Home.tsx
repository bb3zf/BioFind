import { useState, useEffect } from "react";
import { OrganismIdentification, IdentifyOrganismResponse, GetIdentificationsResponse } from "@/shared/types";
import OrganismCard from "@/react-app/components/OrganismCard";
import IdentificationForm from "@/react-app/components/IdentificationForm";
import { Leaf, History, Sparkles } from "lucide-react";

export default function Home() {
  const [currentResult, setCurrentResult] = useState<OrganismIdentification | null>(null);
  const [identificationHistory, setIdentificationHistory] = useState<OrganismIdentification[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [showHistory, setShowHistory] = useState(false);

  // Load identification history on component mount
  useEffect(() => {
    loadIdentificationHistory();
  }, []);

  const loadIdentificationHistory = async () => {
    try {
      const response = await fetch("/api/identifications");
      const data: GetIdentificationsResponse = await response.json();
      if (data.success && data.data) {
        setIdentificationHistory(data.data);
      }
    } catch (error) {
      console.error("Failed to load identification history:", error);
    }
  };

  const handleIdentification = async (submitData: { text?: string; image?: File; educationalMode: boolean }) => {
    setIsLoading(true);
    setCurrentResult(null);

    try {
      const formData = new FormData();
      if (submitData.text) {
        formData.append("text", submitData.text);
      }
      if (submitData.image) {
        formData.append("image", submitData.image);
      }
      formData.append("educational_mode", submitData.educationalMode.toString());

      const response = await fetch("/api/identify", {
        method: "POST",
        body: formData,
      });

      const data: IdentifyOrganismResponse = await response.json();

      if (data.success && data.data) {
        setCurrentResult(data.data);
        // Refresh history to include the new identification
        loadIdentificationHistory();
      } else {
        alert(data.error || "Failed to identify organism");
      }
    } catch (error) {
      console.error("Identification error:", error);
      alert("Failed to identify organism. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-emerald-50 to-teal-50">
      {/* Background decoration */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-green-200/30 rounded-full blur-3xl"></div>
        <div className="absolute top-1/2 -left-32 w-64 h-64 bg-emerald-200/30 rounded-full blur-3xl"></div>
        <div className="absolute -bottom-32 left-1/2 w-96 h-96 bg-teal-200/30 rounded-full blur-3xl"></div>
      </div>

      <div className="relative z-10">
        {/* Header */}
        <header className="text-center py-12 px-4">
          <div className="max-w-4xl mx-auto">
            <div className="inline-flex items-center gap-4 mb-6">
              <div className="p-4 bg-gradient-to-r from-green-500 to-emerald-500 rounded-2xl shadow-lg">
                <Leaf className="w-12 h-12 text-white" />
              </div>
              <h1 className="text-6xl font-bold bg-gradient-to-r from-green-600 via-emerald-600 to-teal-600 bg-clip-text text-transparent">
                BioFind
              </h1>
            </div>
            <p className="text-xl text-green-700 leading-relaxed max-w-2xl mx-auto">
              Discover and learn about any living organism with the power of AI. 
              Perfect for nature enthusiasts, students, and researchers.
            </p>
            
            {/* Navigation buttons */}
            <div className="flex justify-center gap-4 mt-8">
              <button
                onClick={() => setShowHistory(false)}
                className={`flex items-center gap-2 px-6 py-3 rounded-full font-semibold transition-all duration-300 ${
                  !showHistory
                    ? "bg-green-500 text-white shadow-lg"
                    : "bg-white/80 text-green-600 hover:bg-white"
                }`}
              >
                <Sparkles className="w-5 h-5" />
                Identify New
              </button>
              <button
                onClick={() => setShowHistory(true)}
                className={`flex items-center gap-2 px-6 py-3 rounded-full font-semibold transition-all duration-300 ${
                  showHistory
                    ? "bg-green-500 text-white shadow-lg"
                    : "bg-white/80 text-green-600 hover:bg-white"
                }`}
              >
                <History className="w-5 h-5" />
                History ({identificationHistory.length})
              </button>
            </div>
          </div>
        </header>

        {/* Main content */}
        <main className="px-4 pb-12">
          {!showHistory ? (
            <div className="max-w-4xl mx-auto space-y-8">
              {/* Identification form */}
              <IdentificationForm onSubmit={handleIdentification} isLoading={isLoading} />

              {/* Current result */}
              {currentResult && (
                <div className="animate-fadeIn">
                  <h2 className="text-2xl font-bold text-green-800 mb-6 text-center">
                    🎉 Identification Complete!
                  </h2>
                  <OrganismCard identification={currentResult} />
                </div>
              )}
            </div>
          ) : (
            <div className="max-w-6xl mx-auto">
              <h2 className="text-3xl font-bold text-green-800 mb-8 text-center">
                Your Identification History
              </h2>
              
              {identificationHistory.length === 0 ? (
                <div className="text-center py-16">
                  <div className="w-24 h-24 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
                    <History className="w-12 h-12 text-green-500" />
                  </div>
                  <p className="text-xl text-green-700 mb-4">No identifications yet</p>
                  <p className="text-green-600 mb-8">Start by identifying your first organism!</p>
                  <button
                    onClick={() => setShowHistory(false)}
                    className="bg-gradient-to-r from-green-500 to-emerald-500 text-white px-8 py-3 rounded-full font-semibold hover:from-green-600 hover:to-emerald-600 transition-all duration-300"
                  >
                    Get Started
                  </button>
                </div>
              ) : (
                <div className="grid lg:grid-cols-2 gap-8">
                  {identificationHistory.map((identification) => (
                    <OrganismCard key={identification.id} identification={identification} />
                  ))}
                </div>
              )}
            </div>
          )}
        </main>
      </div>
    </div>
  );
}
