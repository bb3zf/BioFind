import z from "zod";

export const OrganismIdentificationSchema = z.object({
  id: z.number(),
  user_input_text: z.string().nullable(),
  image_key: z.string().nullable(),
  organism_name: z.string(),
  common_name: z.string(),
  scientific_classification: z.string(),
  habitat: z.string(),
  diet: z.string(),
  benefits: z.string(),
  unique_characteristics: z.string(),
  conservation_status: z.string(),
  confidence_score: z.number(),
  is_educational_mode: z.boolean(),
  created_at: z.string(),
  updated_at: z.string(),
});

export type OrganismIdentification = z.infer<typeof OrganismIdentificationSchema>;

export const IdentifyOrganismRequestSchema = z.object({
  text: z.string().optional(),
  imageFile: z.instanceof(File).optional(),
  educational_mode: z.boolean().default(false),
}).refine(data => data.text || data.imageFile, {
  message: "Either text or image must be provided"
});

export type IdentifyOrganismRequest = z.infer<typeof IdentifyOrganismRequestSchema>;

export const IdentifyOrganismResponseSchema = z.object({
  success: z.boolean(),
  data: OrganismIdentificationSchema.optional(),
  error: z.string().optional(),
});

export type IdentifyOrganismResponse = z.infer<typeof IdentifyOrganismResponseSchema>;

export const GetIdentificationsResponseSchema = z.object({
  success: z.boolean(),
  data: z.array(OrganismIdentificationSchema).optional(),
  error: z.string().optional(),
});

export type GetIdentificationsResponse = z.infer<typeof GetIdentificationsResponseSchema>;
