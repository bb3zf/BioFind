import { Hono } from "hono";
import { cors } from "hono/cors";
import OpenAI from "openai";
import { OrganismIdentification, IdentifyOrganismResponse, GetIdentificationsResponse } from "@/shared/types";

const app = new Hono<{ Bindings: Env }>();

app.use("/api/*", cors());

// Get organism identification by image or text
app.post("/api/identify", async (c) => {
  try {
    const formData = await c.req.formData();
    const text = formData.get("text") as string;
    const imageFile = formData.get("image") as File;
    const educational_mode = formData.get("educational_mode") === "true";

    if (!text && !imageFile) {
      return c.json<IdentifyOrganismResponse>({
        success: false,
        error: "Either text or image must be provided"
      }, 400);
    }

    const openai = new OpenAI({
      apiKey: c.env.OPENAI_API_KEY,
    });

    let imageKey: string | null = null;
    let prompt = "";

    // Handle image upload if provided
    if (imageFile) {
      const imageBuffer = await imageFile.arrayBuffer();
      imageKey = `identifications/${Date.now()}_${imageFile.name}`;
      
      await c.env.R2_BUCKET.put(imageKey, imageBuffer, {
        httpMetadata: {
          contentType: imageFile.type,
        },
      });

      // Convert image to base64 for OpenAI
      const base64Image = btoa(String.fromCharCode(...new Uint8Array(imageBuffer)));
      const imageUrl = `data:${imageFile.type};base64,${base64Image}`;

      prompt = educational_mode 
        ? `Analyze this image of a living organism and provide detailed educational information suitable for students and researchers. Include: 1) Organism name (common and scientific), 2) Complete taxonomic classification, 3) Habitat and distribution, 4) Diet and feeding behavior, 5) Ecological benefits and role, 6) Unique characteristics and adaptations, 7) Conservation status. Format as a comprehensive but easy-to-understand educational summary.`
        : `Identify this living organism in the image and provide: 1) Common and scientific name, 2) Basic taxonomic classification, 3) Natural habitat, 4) Primary diet, 5) Key benefits to ecosystem, 6) Most distinctive characteristics, 7) Conservation status. Keep information concise but informative.`;

      const response = await openai.chat.completions.create({
        model: "gpt-4o-mini",
        messages: [
          {
            role: "user",
            content: [
              { type: "text", text: prompt },
              { type: "image_url", image_url: { url: imageUrl } }
            ]
          }
        ],
        response_format: {
          type: "json_schema",
          json_schema: {
            name: "organism_identification",
            schema: {
              type: "object",
              properties: {
                organism_name: { type: "string" },
                common_name: { type: "string" },
                scientific_classification: { type: "string" },
                habitat: { type: "string" },
                diet: { type: "string" },
                benefits: { type: "string" },
                unique_characteristics: { type: "string" },
                conservation_status: { type: "string" },
                confidence_score: { type: "number", minimum: 0, maximum: 1 }
              },
              required: ["organism_name", "common_name", "scientific_classification", "habitat", "diet", "benefits", "unique_characteristics", "conservation_status", "confidence_score"],
              additionalProperties: false
            },
            strict: true
          }
        }
      });

      const aiResult = JSON.parse(response.choices[0].message.content || "{}");
      
      // Store in database
      const result = await c.env.DB.prepare(`
        INSERT INTO identifications (user_input_text, image_key, organism_name, common_name, scientific_classification, habitat, diet, benefits, unique_characteristics, conservation_status, confidence_score, is_educational_mode)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).bind(
        null,
        imageKey,
        aiResult.organism_name,
        aiResult.common_name,
        aiResult.scientific_classification,
        aiResult.habitat,
        aiResult.diet,
        aiResult.benefits,
        aiResult.unique_characteristics,
        aiResult.conservation_status,
        aiResult.confidence_score,
        educational_mode ? 1 : 0
      ).run();

      const identification = await c.env.DB.prepare(`
        SELECT * FROM identifications WHERE id = ?
      `).bind(result.meta.last_row_id).first() as OrganismIdentification;

      return c.json<IdentifyOrganismResponse>({
        success: true,
        data: identification
      });
    }

    // Handle text input
    if (text) {
      prompt = educational_mode
        ? `Provide detailed educational information about "${text}" (if it's a living organism). Include: 1) Organism name (common and scientific), 2) Complete taxonomic classification, 3) Habitat and distribution, 4) Diet and feeding behavior, 5) Ecological benefits and role, 6) Unique characteristics and adaptations, 7) Conservation status. Format as a comprehensive educational summary suitable for students and researchers.`
        : `Identify and provide information about "${text}" (if it's a living organism): 1) Common and scientific name, 2) Basic taxonomic classification, 3) Natural habitat, 4) Primary diet, 5) Key benefits to ecosystem, 6) Most distinctive characteristics, 7) Conservation status. Keep information concise but informative.`;

      const response = await openai.chat.completions.create({
        model: "gpt-4o-mini",
        messages: [
          { role: "user", content: prompt }
        ],
        response_format: {
          type: "json_schema",
          json_schema: {
            name: "organism_identification",
            schema: {
              type: "object",
              properties: {
                organism_name: { type: "string" },
                common_name: { type: "string" },
                scientific_classification: { type: "string" },
                habitat: { type: "string" },
                diet: { type: "string" },
                benefits: { type: "string" },
                unique_characteristics: { type: "string" },
                conservation_status: { type: "string" },
                confidence_score: { type: "number", minimum: 0, maximum: 1 }
              },
              required: ["organism_name", "common_name", "scientific_classification", "habitat", "diet", "benefits", "unique_characteristics", "conservation_status", "confidence_score"],
              additionalProperties: false
            },
            strict: true
          }
        }
      });

      const aiResult = JSON.parse(response.choices[0].message.content || "{}");
      
      // Store in database
      const result = await c.env.DB.prepare(`
        INSERT INTO identifications (user_input_text, image_key, organism_name, common_name, scientific_classification, habitat, diet, benefits, unique_characteristics, conservation_status, confidence_score, is_educational_mode)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).bind(
        text,
        null,
        aiResult.organism_name,
        aiResult.common_name,
        aiResult.scientific_classification,
        aiResult.habitat,
        aiResult.diet,
        aiResult.benefits,
        aiResult.unique_characteristics,
        aiResult.conservation_status,
        aiResult.confidence_score,
        educational_mode ? 1 : 0
      ).run();

      const identification = await c.env.DB.prepare(`
        SELECT * FROM identifications WHERE id = ?
      `).bind(result.meta.last_row_id).first() as OrganismIdentification;

      return c.json<IdentifyOrganismResponse>({
        success: true,
        data: identification
      });
    }

  } catch (error) {
    console.error("Error identifying organism:", error);
    return c.json<IdentifyOrganismResponse>({
      success: false,
      error: "Failed to identify organism. Please try again."
    }, 500);
  }
});

// Get identification history
app.get("/api/identifications", async (c) => {
  try {
    const results = await c.env.DB.prepare(`
      SELECT * FROM identifications ORDER BY created_at DESC LIMIT 50
    `).all();

    return c.json<GetIdentificationsResponse>({
      success: true,
      data: results.results as OrganismIdentification[]
    });
  } catch (error) {
    console.error("Error fetching identifications:", error);
    return c.json<GetIdentificationsResponse>({
      success: false,
      error: "Failed to fetch identification history"
    }, 500);
  }
});

// Serve uploaded images
app.get("/api/images/:key", async (c) => {
  try {
    const key = c.req.param("key");
    const object = await c.env.R2_BUCKET.get(`identifications/${key}`);
    
    if (!object) {
      return c.notFound();
    }

    const headers = new Headers();
    object.writeHttpMetadata(headers);
    headers.set("etag", object.httpEtag);
    
    return c.body(object.body, { headers });
  } catch (error) {
    console.error("Error serving image:", error);
    return c.notFound();
  }
});

export default app;
