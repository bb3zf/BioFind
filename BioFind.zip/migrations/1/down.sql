
DROP INDEX idx_identifications_organism_name;
DROP INDEX idx_identifications_created_at;
DROP TABLE identifications;
