
CREATE TABLE identifications (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_input_text TEXT,
  image_key TEXT,
  organism_name TEXT,
  common_name TEXT,
  scientific_classification TEXT,
  habitat TEXT,
  diet TEXT,
  benefits TEXT,
  unique_characteristics TEXT,
  conservation_status TEXT,
  confidence_score REAL,
  is_educational_mode BOOLEAN DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_identifications_created_at ON identifications(created_at);
CREATE INDEX idx_identifications_organism_name ON identifications(organism_name);
